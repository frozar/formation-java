package fr.gouv.finances.dgfip.banque.v1.services.impl;

import org.springframework.stereotype.Component;

import fr.gouv.finances.dgfip.banque.v1.CompteException;
import fr.gouv.finances.dgfip.banque.v1.entites.CompteBancaire;
import fr.gouv.finances.dgfip.banque.v1.services.CompteBancaireServiceInterface;

@Component
public class CompteBancaireService implements CompteBancaireServiceInterface {

	@Override
	public void afficherSyntheseOperations(CompteBancaire compte) {
		// TODO Auto-generated method stub
		
	}
}
